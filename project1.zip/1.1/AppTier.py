import boto3
import paramiko
import threading
import time

ACCESS_KEY_ID = "AKIAQU4W6URJ573AOKUW" 
SECRET_ACCESS_KEY = "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"

REGION = "us-east-1"

s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
sqs_client = boto3.client('sqs', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
ec2_client = boto3.client('ec2', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
ec2_resource = boto3.resource('ec2', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)

INPUT_BUCKET_NAME = "p1inputbucket"


MAX_INSTANCES = 20

instance_count = 0
max_instance = 0

instance_pool = []  # This will store our active EC2 instance IDs
instance_lock = threading.Lock()

LAUNCH_TEMPLATE_NAME = "p1templatefinal"

launch_template = {
    'LaunchTemplateName': LAUNCH_TEMPLATE_NAME,  # replace with your launch template name
    'Version': '$Default' # replace with the desired version or '$Default' for default version
}



def get_security_group_of_instance(instance_id):
    response = ec2_client.describe_instances(InstanceIds=[instance_id])
    instance_data = response['Reservations'][0]['Instances'][0]
    security_groups = instance_data['SecurityGroups']
    return [sg['GroupId'] for sg in security_groups]

def allow_ssh_inbound_to_security_group(security_group_id):
    try:
        data = ec2_client.authorize_security_group_ingress(
            GroupId=security_group_id,
            IpProtocol='tcp',
            FromPort=22,
            ToPort=22,
            CidrIp='0.0.0.0/0'  # Allows SSH from any IP. Adjust if you want to restrict.
        )
        print(f"Successfully added inbound rule to security group {security_group_id}")
    except boto3.exceptions.botocore.exceptions.ClientError as e:
        if "Duplicate" in str(e):
            print(f"Rule already exists in security group {security_group_id}")
        else:
            raise


def create_ec2_instance(instance_name):
    

    response = ec2_client.run_instances(
        LaunchTemplate=launch_template,
        MinCount=1,
        MaxCount=1,  # adjust counts as per your requirement
        TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': instance_name
                }
            ]
        }
    ])


    print("Instance Createed", instance_name, response['Instances'][0]['InstanceId'])

    time.sleep(2) 

    instance_id = response['Instances'][0]['InstanceId']

    return response['Instances'][0]['InstanceId']

def process_image_on_instance(instance_id, image_name):
    # Get public IP for SSH
    instance = ec2_resource.Instance(instance_id)
    instance_ip = instance.public_ip_address

    # Set up SSH client
    key = paramiko.RSAKey.from_private_key_file(filename='p1keypair.pem')
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=instance_ip, username='ubuntu', pkey=key)

    # Run the deep learning model
    classification_command = f"cd /home/ubuntu/ && python3 image_classification.py {image_name}"
    stdin, stdout, stderr = client.exec_command(classification_command)
    result = stdout.read().decode()

    client.close()
    return result


def terminate_all_instances():
    print("Total Instances", instance_count)
    print("Terminating all active instances...")
    if instance_pool:  # Check if the pool is not empty
        ec2_client.terminate_instances(InstanceIds=instance_pool)
        del instance_pool[:]  # Clear the instance pool list



