import boto3
import os
import time
import queue
import threading
from concurrent.futures import ThreadPoolExecutor
from AppTier import process_image_on_instance, create_ec2_instance


#Access key: AKIAQU4W6URJ573AOKUW   Secret Access Key: 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
ACCESS_KEY_ID = "AKIAQU4W6URJ573AOKUW"
SECRET_ACCESS_KEY = "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"

REGION = "us-east-1"

INPUT_BUCKET_NAME = "p1inputbucket"
REQUEST_QUEUE_NAME = "p1requestqueue"
RESPONSE_QUEUE_NAME = "p1responsequeue"

MAX_INSTANCES = 20

s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
s3_resource = s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
sqs_client = boto3.client('sqs', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
ec2_client = boto3.client('ec2', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)



response = sqs_client.get_queue_url(QueueName=REQUEST_QUEUE_NAME)
REQUEST_QUEUE_URL = response['QueueUrl']

response1 = sqs_client.get_queue_url(QueueName=REQUEST_QUEUE_NAME)
RESPONSE_QUEUE_URL = response1['QueueUrl']

folder = ""

instance_queue = queue.Queue()

def clear_all():
     bucket = s3_resource.Bucket(INPUT_BUCKET_NAME)
     bucket.objects.all().delete()  # This deletes all objects in the bucket
     
     while True:
        messages = sqs_client.receive_message(QueueUrl=REQUEST_QUEUE_URL, MaxNumberOfMessages=10)
        if 'Messages' not in messages:
            break  # The queue is empty

        for message in messages['Messages']:
            sqs_client.delete_message(QueueUrl=REQUEST_QUEUE_URL, ReceiptHandle=message['ReceiptHandle'])

def upload_to_sqs(name):
     response = sqs_client.send_message(
            QueueUrl=REQUEST_QUEUE_URL,
            MessageBody=name
        )
     
     print(f"Image {name} uploaded to queue {REQUEST_QUEUE_NAME} with message ID: {response['MessageId']}")

def upload_to_s3(name):
    s3_client.upload_file(folder, INPUT_BUCKET_NAME, name)
    print(f"Image {name} uploaded to queue {INPUT_BUCKET_NAME}")

def run_image(name):
    instance_id = instance_queue.pop()
    upload_to_s3(name)

    process_image_on_instance(instance_id, name)

    instance_queue.pop(instance_id)

def worker():
    while True:
        instance_id = instance_queue.get()
        if instance_id is None:
            # This is our signal to exit the thread
            break
        
        # Get image from SQS
        response = sqs_client.receive_message(QueueUrl=REQUEST_QUEUE_URL, MaxNumberOfMessages=1)
        messages = response.get('Messages')
        if messages:
            image_name = messages[0]['Body']
            upload_to_s3(image_name)
            process_image_on_instance(image_name, instance_id)
            sqs_client.delete_message(QueueUrl=REQUEST_QUEUE_URL, ReceiptHandle=messages[0]['ReceiptHandle'])

        # Put instance back in the queue
        instance_queue.put(instance_id)

def scale_instances(target_count):
    current_count = instance_queue.qsize()
    
    # Start new instances
    for i in range(target_count - current_count):
        instance_name = "instance" + str(i)
        instance_id = create_ec2_instance(instance_name)
        instance_queue.put(instance_id)
    
    # Terminate extra instances
    for _ in range(current_count - target_count):
        instance_id = instance_queue.get()
        ec2_client.terminate_instances(InstanceIds=[instance_id])

def controller(num_request, image_folder):
    
    #clear_all()

    folder = image_folder

    #handle inputs
    for i, name in enumerate(os.listdir(image_folder)):
        if i == num_request:
                break
        upload_to_sqs(name)
        
    print("Waiting for 30 seconds before processing...")
    time.sleep(30)  # Wait for 30 seconds

    attributes = sqs_client.get_queue_attributes(QueueUrl=REQUEST_QUEUE_URL, AttributeNames=['ApproximateNumberOfMessages'])
    # Extract the approximate number of messages in the queu
    num_messages = int(attributes['Attributes']['ApproximateNumberOfMessages'])
    print(f"Approximate number of messages in the queue: {num_messages}")
    print("Waiting for 5 seconds before running thread...")

    time.sleep(5)  # Wait for 30 second

    handled = 0

    for i in range(min(MAX_INSTANCES, num_request)):
        name = "Instance " + str(i)
        instance_id = create_ec2_instance(name)
        instance_queue.put(instance_id)


    print("size of instance queue:", instance_queue.qsize())
    
    threads = []


    # Start worker threads
    for _ in range(min(MAX_INSTANCES, num_request)):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)


    try:
        while True:
            # Here, we're checking the number of messages (images) in the SQS queue
            response = sqs_client.get_queue_attributes(QueueUrl=REQUEST_QUEUE_NAME, AttributeNames=['ApproximateNumberOfMessages'])
            num_messages = int(response['Attributes']['ApproximateNumberOfMessages'])

            # Scale up or down based on the number of images
            scale_instances(min(num_request, num_messages))

    except KeyboardInterrupt:
        pass


    # Stop worker threads
    for _ in range(min(MAX_INSTANCES, num_request)):
        instance_queue.put(None)
    for t in threads:
        t.join()




"""     while handled < num_request:
        # Fetch a message from SQS queue
        messages = sqs_client.receive_message(QueueUrl=REQUEST_QUEUE_URL, MaxNumberOfMessages=1)
        
        if 'Messages' not in messages:
            print("Queue is empty.")
            time.sleep(10)
            return

        handled += 1

        message = messages['Messages'][0]
        image_name = message['Body']
        
        
        run_image(image_name)

        time.sleep(1)

        # Now, process the image using the provided EC2 instance
        # For simplicity, this step is abstracted; you'd likely SSH into the EC2 instance, trigger processing, etc.
        
        # After processing, delete the message from the SQS queue to prevent re-processing
        sqs_client.delete_message(QueueUrl=REQUEST_QUEUE_URL, ReceiptHandle=message['ReceiptHandle']) """



