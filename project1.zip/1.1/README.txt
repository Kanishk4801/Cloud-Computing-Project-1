Group Members:
  Aarin Shah - 1218518119
  Charulatha Sampath - 1229479604
  Kanishk Goswami -  1229608863

Tasks:
  Aarin Shah
    Tested building implementation on Java before the team ultimately decided to do the project in Python. Focused on completely building the web tier side. As well as editing the code on the EC2 template to allow it to interact with S3 and run the model. Then made the template for the EC2 instance so that it could be used to create more instances for autoscaling. Helped build and deploy S3 and SQS modules to connect with EC2 instances on AppTier. Additionally, built the workload generator and configured different files and modules to work together.  
  Charulatha Sampath
    Started with implementation of the project in python and then decided to continue with the same. Worked on web-tier and data-tier, ensuring seamless input of images from the S3 input bucket, followed by processing in the deep learning model and returned results to the S3 output bucket. Optimized the workflow by automating and interconnecting the stages of instance creation, fetching input, executing the model and storing the output, giving an efficient project pipeline.
  Kanishk Goswam
    Worked on the code to upload the test images from the user’s folder to the S3 input bucket and store their names in the SQS Request queue. Additionally, worked on python code to create and run EC2 instances, and to upload the classification fetched from the deep learning model to the response queue  and the output S3 bucket.

AWS resources:
  ACCESS_KEY_ID = "AKIAQU4W6URJ573AOKUW"
  SECRET_ACCESS_KEY = "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"
  S3 Buckets:
    "p1inputbucket"
    "p1outputbucket"
  SQS Queues:
    "p1requestqueue", "https://sqs.us-east-1.amazonaws.com/044876866643/p1requestqueue"
    "p1responsequeue", "https://sqs.us-east-1.amazonaws.com/044876866643/p1responsequeue"
  E2 Launch Template:
    "p1templatefinal"
  pem Key:
    "p1keypair.pem"
  

python3 multithread_workload_generator.py  --num_request 100 --image_folder imagenet-100

ssh -i "p1keypair.pem" ubuntu@ec2-54-196-178-67.compute-1.amazonaws.com

python3 image_classification.py “test_0.JPEG”
python3 image_classification.py “test_1.JPEG”
python3 image_classification.py “test_2.JPEG”

