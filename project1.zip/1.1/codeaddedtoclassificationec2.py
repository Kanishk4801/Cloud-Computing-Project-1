import boto3
import sys

ACCESS_KEY_ID = "AKIAQU4W6URJ573AOKUW" 
SECRET_ACCESS_KEY = "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"

BUCKET_NAME = "p1inputbucket"
REGION = "us-east-1"

def get_image_from_s3(file_name):
    s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
    obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=file_name)
    image_data = obj['Body'].read()
    return image_data

bucket_name = 'p1inputbucket'
file_name =  sys.argv[1]
img = get_image_from_s3(file_name)



BUCKET_NAME = 'p1outputbucket'
QUEUE_NAME = 'p1responsequeue'

def upload_to_s3_and_sqs(image_name, classification):
    
    sqs_client = boto3.client('sqs', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
    s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)

    # Upload image to S3
    s3_client.put_object(Bucket=BUCKET_NAME, Key=image_name, Body=classification)

    # Get the SQS queue URL
    queue_url = sqs_client.get_queue_url(QueueName=QUEUE_NAME)['QueueUrl']

    # Enqueue image name and classification to SQS
    message_body = {
        'image_name': image_name,
        'classification': classification
    }
    sqs_client.send_message(QueueUrl=queue_url, MessageBody=str(message_body))

    print(f"Image {image_name} uploaded and enqueued with classification {classification}.")

# Example usage
image_path = 'path_to_your_image.jpg'
classification = 'YOUR_IMAGE_CLASSIFICATION'
upload_to_s3_and_sqs(img_name, result)