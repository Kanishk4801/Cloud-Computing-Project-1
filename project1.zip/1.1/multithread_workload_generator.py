import sys

import os
import argparse
import _thread
import time
import subprocess
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed

from WebTier import controller

parser = argparse.ArgumentParser(description='Upload images')
parser.add_argument('--num_request', type=int, help='one image per request')
parser.add_argument('--image_folder', type=str, help='the path of the folder where images are saved on your local machine')

args = parser.parse_args()
##url = args.url




start_time = time.time()

num_request = args.num_request
image_folder = args.image_folder
num_max_workers = 20
image_path_list = []

#print(num_request)

controller(num_request, image_folder)



"""
for i, name in enumerate(os.listdir(image_folder)):
    if i == num_request:
        break
    upload_to_s3(name, image_folder + "/" + name)
    image_path_list.append(image_folder + name)
"""    

    

"""
with ThreadPoolExecutor(max_workers = num_max_workers) as executor:
      executor.map(send_one_request, image_path_list)
"""