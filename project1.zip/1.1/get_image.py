import boto3
import sys

ACCESS_KEY_ID = "AKIAQU4W6URJ573AOKUW" 
SECRET_ACCESS_KEY = "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"

BUCKET_NAME = "p1inputbucket"
REGION = "us-east-1"


def download_from_s3(bucket_name, file_name, download_path):
    s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY_ID, aws_secret_access_key=SECRET_ACCESS_KEY,region_name=REGION)
    try:
        s3_client.download_file(bucket_name, file_name, download_path)
        print(f'Successfully downloaded {file_name} to {download_path}')
    except Exception as e:
        print(f'Error downloading file: {e}')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: python get_image.py <image_name>')
        sys.exit(1)
    
    # You can change the bucket_name to your specific bucket
    bucket_name = BUCKET_NAME
    file_name = sys.argv[1]
    download_path = file_name  # You can modify this to save the file to a different directory if needed

    download_from_s3(bucket_name, file_name, download_path)




